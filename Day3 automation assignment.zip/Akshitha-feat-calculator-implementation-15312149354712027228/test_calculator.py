import unittest
from calculator import (
    add,
    subtract,
    multiply,
    divide,
    power,
    modulo,
    square_root,
    Calculator,
)


class TestCalculatorFunctions(unittest.TestCase):

    def test_add(self):
        self.assertEqual(add(2, 3), 5)
        self.assertEqual(add(-1, 1), 0)
        self.assertEqual(add(-5, -5), -10)
        self.assertAlmostEqual(add(0.1, 0.2), 0.3)

    def test_subtract(self):
        self.assertEqual(subtract(10, 4), 6)
        self.assertEqual(subtract(4, 10), -6)
        self.assertEqual(subtract(-1, -1), 0)

    def test_multiply(self):
        self.assertEqual(multiply(3, 4), 12)
        self.assertEqual(multiply(-3, 4), -12)
        self.assertEqual(multiply(0, 100), 0)

    def test_divide(self):
        self.assertEqual(divide(10, 2), 5)
        self.assertEqual(divide(5, 2), 2.5)
        with self.assertRaises(ValueError):
            divide(10, 0)

    def test_power(self):
        self.assertEqual(power(2, 3), 8)
        self.assertEqual(power(5, 0), 1)
        self.assertEqual(power(4, 0.5), 2)

    def test_modulo(self):
        self.assertEqual(modulo(10, 3), 1)
        self.assertEqual(modulo(10, 5), 0)
        with self.assertRaises(ValueError):
            modulo(10, 0)

    def test_square_root(self):
        self.assertEqual(square_root(16), 4)
        self.assertEqual(square_root(0), 0)
        with self.assertRaises(ValueError):
            square_root(-4)


class TestCalculatorClass(unittest.TestCase):

    def setUp(self):
        self.calc = Calculator()

    def test_initial_state(self):
        self.assertEqual(self.calc.memory, 0.0)

    def test_chain_operations(self):
        self.assertEqual(self.calc.add(10), 10)
        self.assertEqual(self.calc.subtract(2), 8)
        self.assertEqual(self.calc.multiply(3), 24)
        self.assertEqual(self.calc.divide(4), 6)

    def test_divide_by_zero(self):
        with self.assertRaises(ValueError):
            self.calc.divide(0)

    def test_reset(self):
        self.calc.add(50)
        self.assertEqual(self.calc.reset(), 0.0)
        self.assertEqual(self.calc.memory, 0.0)


if __name__ == "__main__":
    unittest.main()
