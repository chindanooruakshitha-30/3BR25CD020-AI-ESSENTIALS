# Python Calculator

A flexible Python calculator providing standard arithmetic functions, stateful memory calculations, and an interactive command-line interface (CLI).

## Features

- **Standard Operations**: Addition, subtraction, multiplication, division, power (`^`), modulo (`%`), and square root (`sqrt`).
- **Error Handling**: Handles division by zero and invalid square roots gracefully.
- **Stateful Calculator Class**: Maintains a running total in memory for chained calculations.
- **Interactive CLI**: Menu-driven interface for terminal use.

## Usage

### Using as a Module

```python
import calculator

# Basic functions
res_add = calculator.add(10, 5)        # 15.0
res_div = calculator.divide(10, 2)     # 5.0
res_sqrt = calculator.square_root(16)  # 4.0

# Using Calculator class
calc = calculator.Calculator()
calc.add(10)       # Memory: 10.0
calc.multiply(2)   # Memory: 20.0
calc.subtract(5)   # Memory: 15.0
calc.reset()       # Memory: 0.0
```

### Running the Interactive CLI

Run `calculator.py` directly from the terminal:

```bash
python3 calculator.py
```

### Running Tests

Run the test suite using `unittest`:

```bash
python3 -m unittest discover
```
