"""
A versatile calculator module in Python supporting basic arithmetic operations,
power, square root, modulo, and an interactive CLI.
"""

import math


def add(a: float, b: float) -> float:
    """Returns the sum of a and b."""
    return a + b


def subtract(a: float, b: float) -> float:
    """Returns the difference of a and b."""
    return a - b


def multiply(a: float, b: float) -> float:
    """Returns the product of a and b."""
    return a * b


def divide(a: float, b: float) -> float:
    """Returns the quotient of a and b.

    Raises:
        ValueError: If b is 0.
    """
    if b == 0:
        raise ValueError("Cannot divide by zero.")
    return a / b


def power(a: float, b: float) -> float:
    """Returns a raised to the power of b."""
    return a ** b


def modulo(a: float, b: float) -> float:
    """Returns the remainder of a divided by b.

    Raises:
        ValueError: If b is 0.
    """
    if b == 0:
        raise ValueError("Cannot modulo by zero.")
    return a % b


def square_root(a: float) -> float:
    """Returns the square root of a.

    Raises:
        ValueError: If a is negative.
    """
    if a < 0:
        raise ValueError("Cannot calculate square root of a negative number.")
    return math.sqrt(a)


class Calculator:
    """Calculator class that maintains memory of results."""

    def __init__(self):
        self.memory = 0.0

    def add(self, value: float) -> float:
        self.memory += value
        return self.memory

    def subtract(self, value: float) -> float:
        self.memory -= value
        return self.memory

    def multiply(self, value: float) -> float:
        self.memory *= value
        return self.memory

    def divide(self, value: float) -> float:
        if value == 0:
            raise ValueError("Cannot divide by zero.")
        self.memory /= value
        return self.memory

    def reset(self) -> float:
        self.memory = 0.0
        return self.memory


def main():
    """Interactive Command Line Interface for Calculator."""
    print("====================================")
    print("       Python Calculator CLI        ")
    print("====================================")
    print("Operations:")
    print("  1. Add (+)")
    print("  2. Subtract (-)")
    print("  3. Multiply (*)")
    print("  4. Divide (/)")
    print("  5. Power (^)")
    print("  6. Modulo (%)")
    print("  7. Square Root (sqrt)")
    print("  8. Exit")
    print("====================================")

    while True:
        try:
            choice = input("\nSelect operation (1-8): ").strip()
            if choice in ("8", "exit", "quit"):
                print("Goodbye!")
                break

            if choice in ("7", "sqrt", "square_root"):
                num = float(input("Enter number: "))
                result = square_root(num)
                print(f"Result: √{num} = {result}")
            elif choice in ("1", "2", "3", "4", "5", "6", "+", "-", "*", "/", "^", "%"):
                num1 = float(input("Enter first number: "))
                num2 = float(input("Enter second number: "))

                if choice in ("1", "+"):
                    print(f"Result: {num1} + {num2} = {add(num1, num2)}")
                elif choice in ("2", "-"):
                    print(f"Result: {num1} - {num2} = {subtract(num1, num2)}")
                elif choice in ("3", "*"):
                    print(f"Result: {num1} * {num2} = {multiply(num1, num2)}")
                elif choice in ("4", "/"):
                    print(f"Result: {num1} / {num2} = {divide(num1, num2)}")
                elif choice in ("5", "^"):
                    print(f"Result: {num1} ^ {num2} = {power(num1, num2)}")
                elif choice in ("6", "%"):
                    print(f"Result: {num1} % {num2} = {modulo(num1, num2)}")
            else:
                print("Invalid input choice. Please select 1 through 8.")
        except ValueError as err:
            print(f"Error: {err}")
        except (KeyboardInterrupt, EOFError):
            print("\nGoodbye!")
            break


if __name__ == "__main__":
    main()
